This is not gamesense.pub crack; this was gamesensepub orgs repo gamesense, it's a private repo, you can verify my fork of it on my page: https://github.com/h4xrOx/gamesense.bar  AND  by visiting the following url: https://api.github.com/orgs/gamesensepub/repos
-------------------------------------------------------------------------------------------------------------------------------------------

// The repo:
![image](https://user-images.githubusercontent.com/65768277/139571272-ca6ba74b-1042-4706-a740-8535d2fe2475.png)

``webmaster@gamesense.pub Moderating this section: wish, esoterik and 1al9o (second coder of the loader)``

_```Discovering hacking and leaking/cracking attempts from our server: 12/1/20```_

``(Private Repo for later use)``
-------------------------------------------------------------------------------------------------------------------------------------------
// The DLL testing.dll gamesense team members buildt from reversing gamesense.bar's claim to a "cracked gamesense ", and the only origional gamesense  file they found as mentioned in their commit history was rainbow bar. 
-------------------------------------------------------------------------------------------------------------------------------------------
![image](https://user-images.githubusercontent.com/65768277/139571485-830f7335-6568-40ba-ae94-d203731d71ee.png)
-------------------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------------//
 The only gamesense.pub info I got from reversing testing.dll and debugging reflectiveloader.exe came from their reflective //  loader esotk buildt from gamesense.pub loader source. Apparently to test, the testing.dll they buildt from reversing
gamesense.bar's " crack " .  The only useful gamesense.pub information retrieved from this  was the endpoints I got from 
debugging the the  reflective loader. That gave me endpoint to their project for the gamesense client for visual studio 
teams 
//---------------------------------------------------------------------------------------------------------------------------------------//
-------------------------------------------------------------------------------------------------------------------------------------------
The master key is a solution to protect those POST requests that don't require user to be authenticated. This should not be exposed to the client. however the endpoints were a big find because I got the  Public Key Infrastructure (PKI) this is a system of processes, technologies, and policies that allows you to encrypt and sign data. Their mistake of exposing the endpoints allow everyone to get an access_token, which means everyone can make POST requests issuing digital certificates that authenticate the identity of users, devices, or services.These certificates used for Active Directory Certificates Services (AD CS) for their Visual Studio Teams AD connected services
-------------------------------------------------------------------------------------------------------------------------------------------
![image](https://user-images.githubusercontent.com/65768277/139571160-11be93ce-796b-436f-a37a-51104361f895.png)
-------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------
//ADCS

```is Microsoft’s on-premise PKI solution and while it has been around for some time, there can still be a lot of confusion around the set-up process.```
-------------------------------------------------------------------------------------------------------------------------------------------
//When I see a custom PKI , when I see self signed certificates while pentesting cheat sites, or skid services: I know I will be able //to exploit some mistake or misconfiguration by spoofing , forging and if I am really lucky - a master key to generate CA's //that validate my device to use one of the domains trusted users. 

//Interestingly enough I did get the MASTER-KEY:
-------------------------------------------------------------------------------------------------------------------------------------------
SSL_SESSION_get_master_key() , this function exposes internal values from the TLS handshake. The security of  TLS session depends on keeping the master key secret. ( their mistake ) open terminal:

// Run:
```openssl s_client --connect gamesense.pub:443 --showcerts --crl_download --debug```
-------------------------------------------------------------------------------------------------------------------------------------------
![image](https://user-images.githubusercontent.com/65768277/139573514-d7a99fd0-0ed3-45ff-b138-444db1c596d9.png)
-------------------------------------------------------------------------------------------------------------------------------------------
// **MASTER KEY**

```Master-Key: 6805BB1AF6A0ACFC91EA9FBCD4107405D50F53D24248BC82B03D2168317FDB9EAA988767F7F79EDF53E83DD53A0F511F```
-------------------------------------------------------------------------------------------------------------------------------------------
![image](https://user-images.githubusercontent.com/65768277/139573545-2176744b-ed1c-4bd8-b25d-8361ad0a7356.png)

-------------------------------------------------------------------------------------------------------------------------------------------
![image](https://user-images.githubusercontent.com/65768277/139571160-11be93ce-796b-436f-a37a-51104361f895.png)
-------------------------------------------------------------------------------------------------------------------------------------------
![image](https://user-images.githubusercontent.com/65768277/139572685-b5b58957-1a46-429a-897a-06d5e9239ad5.png)


Moderating this section: wish, esoterik and 1al9o (second coder of the loader) 

Discovering hacking and leaking/cracking attempts from our server: 12/1/20

(Private Repo for later use)

https://gamesense.pub
![image](https://user-images.githubusercontent.com/65768277/123981410-e7efd900-d987-11eb-86ec-fe575a9cf0ab.png)

![image](https://user-images.githubusercontent.com/65768277/115162039-b2b13b80-a066-11eb-8df5-475e4946d992.png)
![image](https://user-images.githubusercontent.com/65768277/115162052-be9cfd80-a066-11eb-80a3-65bba5f45ea7.png)
![image](https://user-images.githubusercontent.com/65768277/115162055-cd83b000-a066-11eb-9188-4d3fb74345a7.png)
![image](https://user-images.githubusercontent.com/65768277/115162063-dbd1cc00-a066-11eb-9b5f-e395bca94c64.png)
![image](https://user-images.githubusercontent.com/65768277/116791258-a1145e80-aa7e-11eb-818e-e77a723f9bf0.png)



