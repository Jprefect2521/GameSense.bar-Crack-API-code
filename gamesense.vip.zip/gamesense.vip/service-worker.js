
const workerVersion = 1;

self.addEventListener('install', (event) => {
    // cache resources necessary for error page
    event.waitUntil(
        caches.open(`cache-v${workerVersion}`).then((cache) => {
            return cache.addAll([
                '/static/css/font-awesome.min.css',
                '/static/fonts/fontawesome-webfont.eot?v=4.7.0',
                '/static/fonts/fontawesome-webfont.eot?#iefix&v=4.7.0',
                '/static/fonts/fontawesome-webfont.woff2?v=4.7.0',
                '/static/fonts/fontawesome-webfont.ttf?v=4.7.0',
                '/static/fonts/fontawesome-webfont.svg?v=4.7.0',
                'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js',
                '/favicon.ico',
                '/static/img/app/icons-192.png',
                '/static/img/app/icons-512.png',
                '/static/img/app/apple-touch-icon.png',
                '/offline',
            ]);
        })
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keyList) => {
            return Promise.all(keyList.map((key) => {
                if (key !== `cache-v${workerVersion}`) {
                    return caches.delete(key);
                }
            }));
        })
    );
});

self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => {
            return response || fetch(event.request).catch((response) => {
                return caches.match('offline', {
                    ignoreSearch: true,
                });
            });
        })
    );
});
